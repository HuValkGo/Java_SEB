package ee.assignment.junior.books.repo;

import ee.assignment.junior.books.domain.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.ArrayList;

public interface BookRepo extends JpaRepository<Book,String> {
}