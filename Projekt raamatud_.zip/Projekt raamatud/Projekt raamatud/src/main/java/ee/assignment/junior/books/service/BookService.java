package ee.assignment.junior.books.service;

import ee.assignment.junior.books.domain.Book;
import ee.assignment.junior.books.domain.BookDto;
import ee.assignment.junior.books.repo.BookRepo;
import ee.assignment.junior.books.domain.Rating;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class BookService {

    @Autowired
    private BookRepo bookRepo;

    public List<Book> findBooksWithRatings() {
        return bookRepo.findAll();
    }

    public List<BookDto> findBooksWithoutRatings() {
        List<Book> books = bookRepo.findAll();
        return books.stream()
                .map(this::convertBookToBookDto)
                .collect(Collectors.toList());
    }

    public Book createBook(Book book) {
        bookRepo.save(book);
        return book;
    }

    public Book getBookWithRating(String isbn) {
        Optional<Book> book = bookRepo.findById(isbn);
        if (book.isEmpty()) {
            return null;
        }
        return book.get();
    }

    public BookDto getBookWithOutRating(String isbn) {
        Optional<Book> book = bookRepo.findById(isbn);
        if (book.isEmpty()) {
            return null;
        }
        return convertBookToBookDto(book.get());
    }

    private BookDto convertBookToBookDto(Book book) {
        BookDto bookDto = new BookDto();
        bookDto.setIsbn(book.getIsbn());
        bookDto.setAuthor(book.getAuthor());
        // TODO teised setterid ka
        return bookDto;
    }

    public String deleteBook(String isbn) {
        Optional<Book> book = bookRepo.findById(isbn);
        if (book.isEmpty()) {
            return "did not find object";
        }
        bookRepo.delete(book.get());
        return "deleted";
    }

    public Book updateBook(Book book) {
        return bookRepo.save(book);
    }

    public List<Book> getTopRatedBooks(Integer limit) {
        List<Book> books = bookRepo.findAll();
        if (books.isEmpty()) {
            return Collections.emptyList();
        }
        books.sort(Comparator.comparingDouble(this::getAverageRating));
        Collections.reverse(books);
        if (books.size() < limit) {
            return books;
        }
        return books.subList(0, limit);
    }

    private Double getAverageRating(Book book) {
        OptionalDouble average = book.getRatings()
                .stream()
                .mapToInt(Rating::getRating)
                .average();
        if (average.isPresent()) {
            return average.getAsDouble();
        }
        return (double) 0;
    }
}
