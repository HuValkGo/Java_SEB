package ee.assignment.junior.books.controller;

import ee.assignment.junior.books.domain.Rating;
import ee.assignment.junior.books.domain.RatingDto;
import ee.assignment.junior.books.repo.BookRepo;
import ee.assignment.junior.books.repo.RatingRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class RatingController {

    @Autowired
    private RatingRepo repo;
    @Autowired
    private BookRepo bookRepo;

    @GetMapping(path="/rating")
    @ResponseBody
    public List<Rating> getRating(){
        return repo.findAll();
    }

    @PostMapping(path="/rating")
    @ResponseBody
    public Rating addRating(@RequestBody RatingDto ratingDto) throws Exception {
       // Book book = bookRepo.getOne(ratingDto.getIsbn());
        //if(book == null){
       //     throw new Exception("ei leidnud");
       // }
        Rating rating = new Rating();
        rating.setIsbn(ratingDto.getIsbn());
        rating.setRating(ratingDto.getRating());
        return repo.save(rating);
    }

}
