package ee.assignment.junior.books.service;

import ee.assignment.junior.books.domain.Rating;
import ee.assignment.junior.books.domain.RatingDto;
import ee.assignment.junior.books.repo.RatingRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class RatingService {

    @Autowired
    private RatingRepo ratingRepo;

    public Rating addRating(@RequestBody RatingDto ratingDto) throws Exception {
        Rating rating = new Rating();
        rating.setIsbn(ratingDto.getIsbn());
        rating.setRating(ratingDto.getRating());
        return ratingRepo.save(rating);
    }

}
