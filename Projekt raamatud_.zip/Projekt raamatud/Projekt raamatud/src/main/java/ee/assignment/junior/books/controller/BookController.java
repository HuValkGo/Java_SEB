package ee.assignment.junior.books.controller;

import ee.assignment.junior.books.domain.Book;
import ee.assignment.junior.books.domain.BookDto;
import ee.assignment.junior.books.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping(path = "/books/with-rating")
    @ResponseBody
    public List<Book> getBooksWithRatings() {
        return bookService.findBooksWithRatings();
    }

    @GetMapping(path = "/book")
    @ResponseBody
    public List<BookDto> getBooks() {
        return bookService.findBooksWithoutRatings();
    }

    @PostMapping(path = "/addBook")
    @ResponseBody
    public Book addBook(@RequestBody Book book) {
        return bookService.createBook(book);
    }

    @RequestMapping("/book/{isbn}")
    public Book getBook(@PathVariable("isbn") String isbn) {
        return bookService.getBookWithRating(isbn);
    }

    @RequestMapping("/bookWithRating/{isbn}")
    public BookDto getBookWithRating(@PathVariable("isbn") String isbn) {
        return bookService.getBookWithOutRating(isbn);
    }

    @DeleteMapping("/book/{isbn}")
    public String deleteBook(@PathVariable String isbn) {
        return bookService.deleteBook(isbn);
    }

    @PutMapping(path = "/book")
    public Book updateBook(@RequestBody Book book) {
        return bookService.updateBook(book);

    }

    @GetMapping(path = "/top")
    @ResponseBody
    public List<Book> findTopBooks(Integer limit) {
        if (limit == null) {
            // default 100 ?
            limit = 100;
        }
        return bookService.getTopRatedBooks(limit);
    }
}
